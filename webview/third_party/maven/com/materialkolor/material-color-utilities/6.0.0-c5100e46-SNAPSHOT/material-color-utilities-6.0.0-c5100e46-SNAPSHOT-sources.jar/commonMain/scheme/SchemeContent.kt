/*
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.materialkolor.scheme

import com.materialkolor.dynamiccolor.ColorSpec.SpecVersion
import com.materialkolor.dynamiccolor.ColorSpecs
import com.materialkolor.dynamiccolor.DynamicScheme
import com.materialkolor.dynamiccolor.Variant
import com.materialkolor.hct.Hct
import com.materialkolor.palettes.TonalPalette
import com.materialkolor.InternalMaterialKolorApi

/**
 * A scheme that places the source color in Scheme.primaryContainer.
 *
 * Primary Container is the source color, adjusted for color relativity. It maintains constant
 * appearance in light mode and dark mode. This adds ~5 tone in light mode, and subtracts ~5 tone in
 * dark mode.
 *
 * Tertiary Container is an analogous color, specifically, the analog of a color wheel divided into
 * 6, and the precise analog is the one found by increasing hue. This is a scientifically grounded
 * equivalent to rotating hue clockwise by 60 degrees. It also maintains constant appearance.
 */
@OptIn(InternalMaterialKolorApi::class)
class SchemeContent(
  sourceColorHctList: List<Hct>,
  isDark: Boolean,
  contrastLevel: Double,
  specVersion: SpecVersion = DEFAULT_SPEC_VERSION,
  platform: Platform = DEFAULT_PLATFORM,
) :
  DynamicScheme(
    sourceColorHctList,
    Variant.CONTENT,
    isDark,
    contrastLevel,
    platform,
    specVersion,
    ColorSpecs.get(specVersion)
      .getPrimaryPalette(
        Variant.CONTENT,
        sourceColorHctList.first(),
        isDark,
        platform,
        contrastLevel,
      ),
    ColorSpecs.get(specVersion)
      .getSecondaryPalette(
        Variant.CONTENT,
        sourceColorHctList.first(),
        isDark,
        platform,
        contrastLevel,
      ),
    if (
      sourceColorHctList.size > 1 &&
        platform == Platform.WATCH &&
        sourceColorHctList[0].toInt() != sourceColorHctList[1].toInt()
    ) {
      TonalPalette.fromHueAndChroma(sourceColorHctList[1].hue, sourceColorHctList[1].chroma)
    } else {
      ColorSpecs.get(specVersion)
        .getTertiaryPalette(
          Variant.CONTENT,
          sourceColorHctList.first(),
          isDark,
          platform,
          contrastLevel,
        )
    },
    ColorSpecs.get(specVersion)
      .getNeutralPalette(
        Variant.CONTENT,
        sourceColorHctList.first(),
        isDark,
        platform,
        contrastLevel,
      ),
    ColorSpecs.get(specVersion)
      .getNeutralVariantPalette(
        Variant.CONTENT,
        sourceColorHctList.first(),
        isDark,
        platform,
        contrastLevel,
      ),
    ColorSpecs.get(specVersion)
      .getErrorPalette(Variant.CONTENT, sourceColorHctList.first(), isDark, platform, contrastLevel),
  ) {
  constructor(
    sourceColorHct: Hct,
    isDark: Boolean,
    contrastLevel: Double,
    specVersion: SpecVersion = DEFAULT_SPEC_VERSION,
    platform: Platform = DEFAULT_PLATFORM,
  ) : this(listOf(sourceColorHct), isDark, contrastLevel, specVersion, platform)
}
