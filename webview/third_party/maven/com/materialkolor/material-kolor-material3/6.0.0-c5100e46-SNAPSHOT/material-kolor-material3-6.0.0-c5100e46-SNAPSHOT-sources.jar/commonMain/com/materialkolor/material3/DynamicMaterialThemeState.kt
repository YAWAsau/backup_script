package com.materialkolor.material3

import androidx.compose.material3.ColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import com.materialkolor.Contrast
import com.materialkolor.PaletteStyle
import com.materialkolor.dynamiccolor.ColorSpec
import com.materialkolor.dynamiccolor.DynamicScheme
import com.materialkolor.ktx.rememberDynamicScheme

/**
 * Creates a [DynamicMaterialThemeState] that can be remembered across compositions using custom colors.
 *
 * @param[seedColor] The initial seed color to generate the color scheme.
 * @param[isDark] The initial dark mode state.
 * @param[isAmoled] The initial Amoled state.
 * @param[primary] A custom color to modify the primary color in the generated color scheme.
 * @param[secondary] A custom color to modify the secondary color in the generated color scheme.
 * @param[tertiary] A custom color to modify the tertiary color in the generated color scheme.
 * @param[neutral] A custom color to modify the neutral color in the generated color scheme.
 * @param[neutralVariant] A custom color to modify the neutral variant color in the generated color scheme.
 * @param[error] A custom color to modify the error color in the generated color scheme.
 * @param[style] The initial palette style.
 * @param[contrastLevel] The initial contrast level.
 * @param[specVersion] The initial spec version.
 * @param[platform] The initial platform.
 * @param[modifyColorScheme] Use this callback to modify the color scheme once it has been generated.
 * Note that if you modify a color in the scheme, the on* color might not have enough contrast.
 */
@Composable
public fun rememberDynamicMaterialThemeState(
    seedColor: Color,
    isDark: Boolean,
    isAmoled: Boolean = false,
    primary: Color? = null,
    secondary: Color? = null,
    tertiary: Color? = null,
    neutral: Color? = null,
    neutralVariant: Color? = null,
    error: Color? = null,
    style: PaletteStyle = PaletteStyle.TonalSpot,
    contrastLevel: Double = Contrast.Default.value,
    specVersion: ColorSpec.SpecVersion = ColorSpec.SpecVersion.Default,
    platform: DynamicScheme.Platform = DynamicScheme.Platform.Default,
    modifyColorScheme: (DynamicMaterialThemeState.(ColorScheme) -> ColorScheme)? = null,
): DynamicMaterialThemeState =
    remember(
        seedColor,
        isDark,
        isAmoled,
        primary,
        secondary,
        tertiary,
        neutral,
        neutralVariant,
        error,
        style,
        contrastLevel,
        specVersion,
        platform,
        modifyColorScheme,
    ) {
        DynamicMaterialThemeState(
            initialSeedColor = seedColor,
            initialIsDark = isDark,
            initialIsAmoled = isAmoled,
            initialStyle = style,
            initialContrastLevel = contrastLevel,
            initialSpecVersion = specVersion,
            initialPlatform = platform,
            initialPrimary = primary,
            initialSecondary = secondary,
            initialTertiary = tertiary,
            initialNeutral = neutral,
            initialNeutralVariant = neutralVariant,
            initialError = error,
            modifyColorScheme = modifyColorScheme,
        )
    }

/**
 * Creates a [DynamicMaterialThemeState] that can be remembered across compositions using custom colors.
 *
 * **Note:** The [primary] color is used as the seed color and as the primary override, so every
 * palette in the scheme comes from it.
 *
 * @param[primary] The initial seed color, and the primary color of the generated color scheme.
 * @param[isDark] The initial dark mode state.
 * @param[isAmoled] The initial Amoled state.
 * @param[secondary] A custom color to modify the secondary color in the generated color scheme.
 * @param[tertiary] A custom color to modify the tertiary color in the generated color scheme.
 * @param[neutral] A custom color to modify the neutral color in the generated color scheme.
 * @param[neutralVariant] A custom color to modify the neutral variant color in the generated color scheme.
 * @param[error] A custom color to modify the error color in the generated color scheme.
 * @param[style] The initial palette style.
 * @param[contrastLevel] The initial contrast level.
 * @param[specVersion] The initial spec version.
 * @param[platform] The initial platform.
 * @param[modifyColorScheme] Use this callback to modify the color scheme once it has been generated.
 * Note that if you modify a color in the scheme, the on* color might not have enough contrast.
 */
@Deprecated(
    message = "A primary color is an override on top of a seed now. Pass your color as the seed, " +
        "and keep it as primary to get the colors this overload gives you. Removed in 7.0.",
    replaceWith = ReplaceWith(
        "rememberDynamicMaterialThemeState(seedColor = primary, isDark = isDark, " +
            "isAmoled = isAmoled, primary = primary, secondary = secondary, tertiary = tertiary, " +
            "neutral = neutral, neutralVariant = neutralVariant, error = error, style = style, " +
            "contrastLevel = contrastLevel, specVersion = specVersion, platform = platform, " +
            "modifyColorScheme = modifyColorScheme)",
    ),
    level = DeprecationLevel.WARNING,
)
@Composable
public fun rememberDynamicMaterialThemeState(
    primary: Color,
    isDark: Boolean,
    isAmoled: Boolean = false,
    secondary: Color? = null,
    tertiary: Color? = null,
    neutral: Color? = null,
    neutralVariant: Color? = null,
    error: Color? = null,
    style: PaletteStyle = PaletteStyle.TonalSpot,
    contrastLevel: Double = Contrast.Default.value,
    specVersion: ColorSpec.SpecVersion = ColorSpec.SpecVersion.Default,
    platform: DynamicScheme.Platform = DynamicScheme.Platform.Default,
    modifyColorScheme: (DynamicMaterialThemeState.(ColorScheme) -> ColorScheme)? = null,
): DynamicMaterialThemeState =
    remember(
        primary,
        isDark,
        isAmoled,
        secondary,
        tertiary,
        neutral,
        neutralVariant,
        error,
        style,
        contrastLevel,
        specVersion,
        platform,
        modifyColorScheme,
    ) {
        DynamicMaterialThemeState(
            initialSeedColor = primary,
            initialIsDark = isDark,
            initialIsAmoled = isAmoled,
            initialStyle = style,
            initialContrastLevel = contrastLevel,
            initialSpecVersion = specVersion,
            initialPlatform = platform,
            initialPrimary = primary,
            initialSecondary = secondary,
            initialTertiary = tertiary,
            initialNeutral = neutral,
            initialNeutralVariant = neutralVariant,
            initialError = error,
            modifyColorScheme = modifyColorScheme,
        )
    }

/**
 * State object that holds the current values for a dynamic material theme.
 *
 * Use [rememberDynamicMaterialThemeState] to create an instance of this class.
 *
 * @param[initialSeedColor] The initial seed color to generate the color scheme.
 * @param[initialIsDark] The initial dark mode state.
 * @param[initialIsAmoled] The initial Amoled state.
 * @param[initialStyle] The initial palette style.
 * @param[initialContrastLevel] The initial contrast level.
 * @param[initialSpecVersion] The initial spec version.
 * @param[initialPlatform] The initial platform.
 * @param[initialPrimary] A custom color to modify the primary color in the generated color scheme.
 * @param[initialSecondary] A custom color to modify the secondary color in the generated color scheme.
 * @param[initialTertiary] A custom color to modify the tertiary color in the generated color scheme.
 * @param[initialNeutral] A custom color to modify the neutral color in the generated color scheme.
 * @param[initialNeutralVariant] A custom color to modify the neutral variant color in the generated color scheme.
 * @param[initialError] A custom color to modify the error color in the generated color scheme.
 * @param[modifyColorScheme] Use this callback to modify the color scheme once it has been generated.
 * Note that if you modify a color in the scheme, the on* color might not have enough contrast.
 */
@Suppress("MemberVisibilityCanBePrivate")
@Stable
public class DynamicMaterialThemeState internal constructor(
    initialSeedColor: Color,
    initialIsDark: Boolean,
    initialIsAmoled: Boolean,
    initialStyle: PaletteStyle,
    initialContrastLevel: Double,
    initialSpecVersion: ColorSpec.SpecVersion,
    initialPlatform: DynamicScheme.Platform,
    initialPrimary: Color? = null,
    initialSecondary: Color? = null,
    initialTertiary: Color? = null,
    initialNeutral: Color? = null,
    initialNeutralVariant: Color? = null,
    initialError: Color? = null,
    public val modifyColorScheme: (DynamicMaterialThemeState.(ColorScheme) -> ColorScheme)?,
) {
    /**
     * The seed color to generate the color scheme from.
     *
     * @see dynamicColorScheme
     */
    public var seedColor: Color by mutableStateOf(initialSeedColor)

    /**
     * The dark mode state.
     *
     * @see dynamicColorScheme
     */
    public var isDark: Boolean by mutableStateOf(initialIsDark)

    /**
     * The dark mode with Amoled state.
     *
     * @see dynamicColorScheme
     */
    public var isAmoled: Boolean by mutableStateOf(initialIsAmoled)

    /**
     * The palette style.
     *
     * @See PaletteStyle
     * @see dynamicColorScheme
     */
    public var style: PaletteStyle by mutableStateOf(initialStyle)

    /**
     * The contrast level.
     *
     * @see dynamicColorScheme
     */
    public var contrastLevel: Double by mutableStateOf(initialContrastLevel)

    /**
     * The spec version.
     *
     * @see dynamicColorScheme
     */
    public var specVersion: ColorSpec.SpecVersion by mutableStateOf(initialSpecVersion)

    /**
     * The platform.
     *
     * @see dynamicColorScheme
     */
    public var platform: DynamicScheme.Platform by mutableStateOf(initialPlatform)

    /**
     * A custom color to modify the primary color in the generated color scheme.
     *
     * **Note:** This pins the primary palette only, [seedColor] still drives every other palette.
     */
    public var primary: Color? by mutableStateOf(initialPrimary)

    /**
     * A custom color to modify the secondary color in the generated color scheme.
     */
    public var secondary: Color? by mutableStateOf(initialSecondary)

    /**
     * A custom color to modify the tertiary color in the generated color scheme.
     */
    public var tertiary: Color? by mutableStateOf(initialTertiary)

    /**
     * A custom color to modify the neutral color in the generated color scheme.
     */
    public var neutral: Color? by mutableStateOf(initialNeutral)

    /**
     * A custom color to modify the neutral variant color in the generated color scheme.
     */
    public var neutralVariant: Color? by mutableStateOf(initialNeutralVariant)

    /**
     * A custom color to modify the error color in the generated color scheme.
     */
    public var error: Color? by mutableStateOf(initialError)

    /**
     * The generated scheme based on the current state.
     */
    public val dynamicScheme: DynamicScheme
        @Composable
        get() = rememberDynamicScheme(
            seedColor = seedColor,
            isDark = isDark,
            primary = primary,
            secondary = secondary,
            tertiary = tertiary,
            neutral = neutral,
            neutralVariant = neutralVariant,
            error = error,
            style = style,
            contrastLevel = contrastLevel,
            specVersion = specVersion,
            platform = platform,
        )

    /**
     * The generated color scheme based on the current state.
     */
    public val colorScheme: ColorScheme
        @Composable
        get() {
            val callback: ((ColorScheme) -> ColorScheme)? = modifyColorScheme
                ?.let { callback -> { scheme -> callback(this, scheme) } }

            return rememberDynamicColorScheme(
                seedColor = seedColor,
                isDark = isDark,
                isAmoled = isAmoled,
                primary = primary,
                secondary = secondary,
                tertiary = tertiary,
                neutral = neutral,
                neutralVariant = neutralVariant,
                error = error,
                style = style,
                contrastLevel = contrastLevel,
                specVersion = specVersion,
                platform = platform,
                modifyColorScheme = callback,
            )
        }
}
