package com.materialkolor.material3

import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import com.materialkolor.Contrast
import com.materialkolor.InternalMaterialKolorApi
import com.materialkolor.PaletteStyle
import com.materialkolor.dynamiccolor.ColorSpec
import com.materialkolor.dynamiccolor.DynamicScheme
import com.materialkolor.ktx.defaultColorSpring
import com.materialkolor.material3.ktx.animateColorScheme

/**
 * A Material Theme that adapts to the given seed color and the provided custom colors.
 *
 * You can access the current seed color via [LocalDynamicMaterialThemeSeed].
 *
 * @see dynamicColorScheme
 * @see PaletteStyle
 * @param[seedColor] The seed color to use for generating the color scheme.
 * @param[isDark] Whether to use a dark theme or not.
 * @param[isAmoled] Whether the dark scheme is used with Amoled screen (Pure dark).
 * @param[primary] The custom primary color of the color scheme.
 * @param[secondary] The custom secondary color of the color scheme.
 * @param[tertiary] The custom tertiary color of the color scheme.
 * @param[neutral] The custom neutral color of the color scheme.
 * @param[neutralVariant] The custom neutral variant color of the color scheme.
 * @param[error] The custom error color of the color scheme.
 * @param[style] The style of the color scheme.
 * @param[contrastLevel] The contrast level of the color scheme.
 * @param[specVersion] The spec version of the color scheme.
 * @param[platform] The platform of the color scheme.
 * @param[shapes] The shapes of the theme.
 * @param[typography] The typography of the theme.
 * @param[animate] Whether to animate the color scheme or not.
 * @param[animationSpec] The animation spec to use for animating the color scheme.
 * @param[content] The Composable content of the theme.
 */
@OptIn(InternalMaterialKolorApi::class)
@Composable
public fun DynamicMaterialTheme(
    seedColor: Color,
    isDark: Boolean = isSystemInDarkTheme(),
    isAmoled: Boolean = false,
    primary: Color? = null,
    secondary: Color? = null,
    tertiary: Color? = null,
    neutral: Color? = null,
    neutralVariant: Color? = null,
    error: Color? = null,
    style: PaletteStyle = PaletteStyle.TonalSpot,
    contrastLevel: Double = Contrast.Default.value,
    specVersion: ColorSpec.SpecVersion = ColorSpec.SpecVersion.Default,
    platform: DynamicScheme.Platform = DynamicScheme.Platform.Default,
    shapes: Shapes = MaterialTheme.shapes,
    typography: Typography = MaterialTheme.typography,
    animate: Boolean = false,
    animationSpec: FiniteAnimationSpec<Color> = defaultColorSpring,
    content: @Composable () -> Unit,
) {
    val state = rememberDynamicMaterialThemeState(
        seedColor = seedColor,
        isDark = isDark,
        isAmoled = isAmoled,
        primary = primary,
        secondary = secondary,
        tertiary = tertiary,
        neutral = neutral,
        neutralVariant = neutralVariant,
        error = error,
        style = style,
        contrastLevel = contrastLevel,
        specVersion = specVersion,
        platform = platform,
    )

    DynamicMaterialTheme(
        state = state,
        shapes = shapes,
        typography = typography,
        animate = animate,
        animationSpec = animationSpec,
        content = content,
    )
}

/**
 * A Material Theme that adapts to the given seed color and the provided custom colors.
 *
 * You can access the current seed color via [LocalDynamicMaterialThemeSeed].
 *
 * @see dynamicColorScheme
 * @see PaletteStyle
 *
 * **Note:** [primary] is used as the seed color and as the primary override, so every palette in
 * the scheme comes from it.
 *
 * @param[primary] The color the theme is based on, and the primary color of the color scheme.
 * @param[isDark] Whether to use a dark theme or not.
 * @param[isAmoled] Whether the dark scheme is used with Amoled screen (Pure dark).
 * @param[secondary] The custom secondary color of the color scheme.
 * @param[tertiary] The custom tertiary color of the color scheme.
 * @param[neutral] The custom neutral color of the color scheme.
 * @param[neutralVariant] The custom neutral variant color of the color scheme.
 * @param[error] The custom error color of the color scheme.
 * @param[style] The style of the color scheme.
 * @param[contrastLevel] The contrast level of the color scheme.
 * @param[specVersion] The spec version of the color scheme.
 * @param[platform] The platform of the color scheme.
 * @param[shapes] The shapes of the theme.
 * @param[typography] The typography of the theme.
 * @param[animate] Whether to animate the color scheme or not.
 * @param[animationSpec] The animation spec to use for animating the color scheme.
 * @param[content] The Composable content of the theme.
 */
@Deprecated(
    message = "A primary color is an override on top of a seed now. Pass your color as the seed, " +
        "and keep it as primary to get the colors this overload gives you. Removed in 7.0.",
    replaceWith = ReplaceWith(
        "DynamicMaterialTheme(seedColor = primary, isDark = isDark, isAmoled = isAmoled, " +
            "primary = primary, secondary = secondary, tertiary = tertiary, neutral = neutral, " +
            "neutralVariant = neutralVariant, error = error, style = style, " +
            "contrastLevel = contrastLevel, specVersion = specVersion, platform = platform, " +
            "shapes = shapes, typography = typography, animate = animate, " +
            "animationSpec = animationSpec, content = content)",
    ),
    level = DeprecationLevel.WARNING,
)
@OptIn(InternalMaterialKolorApi::class)
@Composable
public fun DynamicMaterialTheme(
    primary: Color,
    isDark: Boolean = isSystemInDarkTheme(),
    isAmoled: Boolean = false,
    secondary: Color? = null,
    tertiary: Color? = null,
    neutral: Color? = null,
    neutralVariant: Color? = null,
    error: Color? = null,
    style: PaletteStyle = PaletteStyle.TonalSpot,
    contrastLevel: Double = Contrast.Default.value,
    specVersion: ColorSpec.SpecVersion = ColorSpec.SpecVersion.Default,
    platform: DynamicScheme.Platform = DynamicScheme.Platform.Default,
    shapes: Shapes = MaterialTheme.shapes,
    typography: Typography = MaterialTheme.typography,
    animate: Boolean = false,
    animationSpec: FiniteAnimationSpec<Color> = defaultColorSpring,
    content: @Composable () -> Unit,
) {
    val state = rememberDynamicMaterialThemeState(
        seedColor = primary,
        isDark = isDark,
        isAmoled = isAmoled,
        primary = primary,
        secondary = secondary,
        tertiary = tertiary,
        neutral = neutral,
        neutralVariant = neutralVariant,
        error = error,
        style = style,
        contrastLevel = contrastLevel,
        specVersion = specVersion,
        platform = platform,
    )

    DynamicMaterialTheme(
        state = state,
        shapes = shapes,
        typography = typography,
        animate = animate,
        animationSpec = animationSpec,
        content = content,
    )
}

/**
 * A Material Theme that adapts to the given [DynamicMaterialThemeState.seedColor].
 *
 * You can access the current seed color via [LocalDynamicMaterialThemeSeed].
 *
 * @see DynamicMaterialThemeState
 * @see PaletteStyle
 * @param[state] The state of the dynamic material theme.
 * @param[animate] Whether to animate the color scheme or not.
 * @param[animationSpec] The animation spec to use for animating the color scheme.
 * @param[content] The Composable content of the theme.
 */
@OptIn(InternalMaterialKolorApi::class)
@Composable
public fun DynamicMaterialTheme(
    state: DynamicMaterialThemeState,
    shapes: Shapes = MaterialTheme.shapes,
    typography: Typography = MaterialTheme.typography,
    animate: Boolean = false,
    animationSpec: FiniteAnimationSpec<Color> = defaultColorSpring,
    content: @Composable () -> Unit,
) {
    val colorScheme = state.colorScheme
    val scheme =
        if (!animate) {
            colorScheme
        } else {
            animateColorScheme(colorScheme = colorScheme, animationSpec = { animationSpec })
        }

    CompositionLocalProvider(LocalDynamicMaterialThemeSeed provides state.seedColor) {
        MaterialTheme(
            colorScheme = scheme,
            shapes = shapes,
            typography = typography,
            content = content,
        )
    }
}
